window.CALCRECS=[];
