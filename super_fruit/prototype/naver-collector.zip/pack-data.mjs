#!/usr/bin/env node
/**
 * 화면에 넣을 수 있게 데이터를 접는다.
 *
 * 왜 필요한가
 *   naver-out/keywords.json  178 MB
 *   naver-out/trend.json     408 MB
 * 대부분이 줄바꿈과 들여쓰기다. 숫자 자체는 훨씬 작다.
 * 그대로는 보낼 수도, 화면에 넣을 수도 없다.
 *
 * 무엇을 하는가
 *   1) 키워드를 배열 한 줄로 접는다          약 90 bytes/키워드
 *   2) 3년 추세 156주를 글자 156개로 접는다   약 170 bytes/키워드
 *      비율 0~100 을 90단계로 눌러 한 주를 한 글자로 만든다. 그래프에선 차이가 안 보인다.
 *   3) 구매층은 천분율 정수 8개로 접는다
 *
 * 키워드는 하나도 버리지 않는다. 접기만 한다.
 *
 * 실행:  node pack-data.mjs                       전부 담는다 (섹션 표시만)
 *        node pack-data.mjs --section 1        과일·채소만
 *        node pack-data.mjs --section 1,2      과일·채소 + 곡물·견과
 */
import fs from "node:fs";
import path from "node:path";

const OUT = "naver-out";
const DST = path.join(OUT, "pack");
const MB = n => (n / 1048576).toFixed(2) + " MB";
const read = f => {
  const full = path.join(OUT, f);
  if (!fs.existsSync(full)) { console.log(`  ${f} 가 없다.`); return null; }
  try { return JSON.parse(fs.readFileSync(full, "utf8")); }
  catch (e) {
    /* 512 MB 를 넘으면 readFileSync 가 문자열을 못 만든다. 삼키면 '파일 없음' 으로 보인다. */
    console.log(`  ${f} 를 통째로 읽지 못했다: ${e.message}`);
    return null;
  }
};
const size = f => { try { return fs.statSync(path.join(OUT, f)).size; } catch { return 0; } };

/* 한 주를 한 글자로. JSON 문자열에서 탈이 나는 " 와 \ 는 뺐다. */
const A = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+,-./:;<=>?@[]^_{|}~";
const enc = v => A[Math.max(0, Math.min(A.length - 1, Math.round((v || 0) / 100 * (A.length - 1))))];

fs.mkdirSync(DST, { recursive: true });
/* 지난번에 만든 조각을 먼저 지운다.
   안 지우면 전에 담은 kw-001 ~ kw-004 가 그대로 남아 폴더가 90 MB 가 된다.
   더 나쁜 건 화면이 옛 조각과 새 조각을 같이 읽어 키워드가 뒤섞인다는 것이다. */
{
  let n = 0;
  for (const f of fs.readdirSync(DST))
    if (/^(kw|trend|shop)[-.].*\.js$/.test(f) || f === "meta.json" || f === "kw.js") {
      fs.unlinkSync(path.join(DST, f)); n++;
    }
  if (n) console.log(`지난번 조각 ${n}개를 지웠다.`);
}
const meta = { builtAt: new Date().toISOString(), alphabet: A };
let total = 0;

/* ── 섹션 ──
   419,049개를 한 화면에 다 넣는 건 무리다. 보갬이 정한 순서대로 자른다.
     1 과일·채소  →  2 곡물·견과·건과  →  3 수산물  →  4 축산물
   그 밖의 카테고리는 나중에 별도 사이트로 뺀다.
   키워드를 버리는 게 아니다. 어느 섹션에 속하는지 표시만 한다.
   한 키워드가 여러 섹션에 속할 수 있다. 어디에도 안 붙으면 0 이다. */
let SEC = null;
try { SEC = JSON.parse(fs.readFileSync("sections.json", "utf8")).sections; } catch {}
let secMatch = () => 0;
if (SEC) {
  const multi = SEC.map(() => new Set()), one = SEC.map(() => []);
  let maxLen = 0;
  SEC.forEach((sec, si) => {
    for (const raw of sec.terms) {
      const w = String(raw).replace(/\s+/g, "");
      if (w.length === 1) one[si].push(w);
      else if (w.length >= 2) { multi[si].add(w); if (w.length > maxLen) maxLen = w.length; }
    }
  });
  /* 비트로 담는다. 1=과일·채소, 2=곡물, 4=수산, 8=축산 */
  secMatch = kw => {
    let m = 0;
    for (let si = 0; si < SEC.length; si++) {
      let hit = false;
      for (let i = 0; i < kw.length && !hit; i++)
        for (let L = 2; L <= Math.min(maxLen, kw.length - i); L++)
          if (multi[si].has(kw.slice(i, i + L))) { hit = true; break; }
      if (!hit)
        for (const c of one[si])
          if (kw === c || kw.slice(-1) === c
              || (kw.slice(0, 1) === c && (kw.length <= 4 || /[0-9A-Za-z]/.test(kw[1])))) { hit = true; break; }
      if (hit) m |= (1 << si);
    }
    return m;
  };
  console.log(`섹션 ${SEC.length}개: ` + SEC.map(x => x.name).join(" · "));
}

/* ── 1. 키워드 ── */
/* keywords.json 도 흘려 읽는다. 566,276개에 252 MB 고 계속 큰다.
   줄이 배열인 새 형식과 객체인 옛 형식을 둘 다 받는다. */
const KW_KEYS = "kw,pc,mo,total,tier,masked,clickPc,clickMo,ctrPc,ctrMo,depth,compIdx,hints,bid,seenAlso".split(",");
async function loadKeywords(file) {
  const out = { meta: {}, rows: [] };
  let fh; try { fh = await fs.promises.open(file, "r"); } catch { return out; }
  const rs = fh.createReadStream({ encoding: "utf8", highWaterMark: 1 << 20 });
  let buf = "", started = false;
  const balanced = from => {
    const open = buf[from], close = open === "[" ? "]" : "}";
    let d = 0, str = false, esc = false;
    for (let i = from; i < buf.length; i++) {
      const c = buf[i];
      if (esc) { esc = false; continue; }
      if (c === "\\") { esc = true; continue; }
      if (c === '"') { str = !str; continue; }
      if (str) continue;
      if (c === open) d++; else if (c === close) { d--; if (!d) return i; }
    }
    return -1;
  };
  const conv = a => {
    if (!Array.isArray(a)) return a;
    const o = {}; KW_KEYS.forEach((k, i) => { o[k] = a[i]; });
    o.masked = !!o.masked; o.hints = o.hints || [];
    o.bid = o.bid ? { pc: o.bid[0], mo: o.bid[1] } : null;
    return o;
  };
  const drain = () => {
    for (;;) {
      let i = 0;
      while (i < buf.length && /[\s,]/.test(buf[i])) i++;
      if (i >= buf.length) { buf = ""; return; }
      if (buf[i] === "]") { buf = ""; return; }
      if (buf[i] !== "{" && buf[i] !== "[") { buf = buf.slice(i); return; }
      const end = balanced(i);
      if (end < 0) { buf = buf.slice(i); return; }
      out.rows.push(conv(JSON.parse(buf.slice(i, end + 1))));
      buf = buf.slice(end + 1);
    }
  };
  for await (const chunk of rs) {
    buf += chunk;
    if (!started) {
      const a = buf.indexOf('"rows"');
      if (a < 0) { if (buf.length > 8000000) buf = buf.slice(-4000000); continue; }
      const b = buf.indexOf("[", a);
      if (b < 0) continue;
      try { out.meta = JSON.parse(buf.slice(0, a).replace(/,\s*$/, "") + "}"); } catch {}
      buf = buf.slice(b + 1); started = true;
    }
    drain();
  }
  if (started) drain();
  return out;
}
const kwFile = path.join(OUT, "keywords.json");
if (!fs.existsSync(kwFile)) { console.error("naver-out/keywords.json 이 없다."); process.exit(1); }
const kwLoaded = await loadKeywords(kwFile);
const kj = kwLoaded.meta;
const rows = kwLoaded.rows;
if (!rows.length) { console.error("naver-out/keywords.json 에서 줄을 하나도 읽지 못했다."); process.exit(1); }
console.log(`키워드 ${rows.length.toLocaleString()}개  (원본 ${MB(size("keywords.json"))})`);

/* ── 최신값 층 (refresh-naver.mjs → naver-out/fresh.json) ──
   keywords.json 은 같은 키워드를 다시 받아도 첫 값을 지켰다. 9/11 값이 9/14 값을 이겼다.
   fresh.json 은 값마다 받은 시각이 있고, 새것이 이긴다. 원본은 그대로 두고 위에 덮는다. */
let freshAt = "";
try {
  const fj = JSON.parse(fs.readFileSync(path.join(OUT, "fresh.json"), "utf8"));
  const FRESH = fj.rows || {}; freshAt = fj.savedAt || fj.startedAt || "";
  let nS = 0, nB = 0, nM = 0, nF = 0, nNo = 0;
  for (const r of rows) {
    const f = FRESH[r.kw]; if (!f) continue;
    if (f.s) { r.sepTot = (+r.pc || 0) + (+r.mo || 0); [r.pc, r.mo, r.masked, r.clickPc, r.clickMo, r.ctrPc, r.ctrMo, r.depth, r.compIdx] = f.s; r.masked = !!r.masked; r.total = r.pc + r.mo; r.at = f.sAt; nS++; }
    if (f.b) { r.bid = { pc: f.b.slice(0, 3), mo: f.b.slice(3, 6) }; nB++; }
    if (f.m) { r.med = f.m; nM++; }
    if (f.f != null) { r.food = f.f; nF++; if (!f.f) nNo++; }
  }
  console.log(`최신값 층 덮음  검색수 ${nS.toLocaleString()} · 입찰가 ${nB.toLocaleString()} · 중간입찰가 ${nM.toLocaleString()} · 식품판정 ${nF.toLocaleString()} (식품 아님 ${nNo.toLocaleString()})  · ${freshAt}`);
} catch (e) {
  /* 파일이 없는 것과 읽다가 터진 것을 구분한다. 삼키면 9월 값이 조용히 나간다 (2026-10-09 한 번 당했다) */
  if (e.code === "ENOENT") console.log("최신값 층(fresh.json) 없음 — 9월 수집본 그대로 담는다. refresh-naver.mjs 를 돌리면 오늘 값으로 바뀐다.");
  else { console.error("최신값 층을 읽다 실패했다: " + e.message); process.exit(1); }
}
const dayInt = t => { if (!t) return 0; const d = new Date(t); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); };

const num = x => (x == null || x === "" ? 0 : (typeof x === "number" ? x : Number(x) || 0));

/* 수집기가 실제로 쓰는 모양에 맞춘다. 처음엔 내가 이름을 잘못 짚어서
   입찰가·경쟁도·힌트가 전부 0 과 빈 문자열로 나갔다.
     bid      { pc:[1위,2위,3위], mo:[...] }   (bp1 같은 평평한 이름이 아니다)
     compIdx  "낮음" | "중간" | "높음"          (comp 라는 숫자가 아니다)
     hints    ["씨앗", ...]                    (hint 문자열이 아니다) */
const COMP = { "낮음": 0, "중간": 1, "높음": 2 };
const bidOf = (r, dev, i) => { const b = r.bid && r.bid[dev]; return b ? num(b[i]) : 0; };

/* 의도 분류. 옛 수집분 13,662개의 라벨과 대조해 77.7% 일치하는 규칙이다.
   완벽하지 않다. 특히 브랜드성이 약하다(26.6%). 화면에서 칩으로 켜고 끄는 용도라
   이 정도면 쓴다. 어느 것도 삭제하지 않는다. */
/* ── 의도 다섯 칸 ──
   넷으로는 안 됐다. 97.1% 가 쇼핑성으로 쏠려서 사실상 분류를 안 하는 상태였고,
   그래서 황금키워드에 고구마줄기볶음 · 콩나물무침이 올라왔다.

   요리명은 쇼핑성도 정보성도 아니다. 밀키트를 팔 수도 있고 레시피를 찾는 것일
   수도 있다. 억지로 한쪽에 밀지 말고 제 칸을 준다. 그래야 사람이 껐다 켰다 한다.
   품목명 단독(멜론 · 사과 · 납작복숭아)은 제일 좋은 판매 키워드라 따로 센다.

   섹션에 걸렸다고 쇼핑성으로 올리던 규칙(secBits)은 뺐다. 그게 쏠림의 원인이었다. */
const RE_HOWTO = /(법|방법)$|만들기|만드는|하는법|끓이는|삶는|데치는|찌는|굽는|볶는|까는|씻는|고르는|해동하는|숙성하는|키우기|재배|심는시기|심는법|수확시기|파종|효능|효과|칼로리|부작용|성분|영양소|유래|뜻$|차이$|시기$|철$|언제|어디|왜|증상|좋은음식|먹으면|주의사항|맛집|가볼만한곳/;
const RE_DISH  = /볶음|무침|조림|찜$|구이|튀김|부침|전$|전골|찌개|탕$|국$|죽$|샐러드|스무디|주스|반찬|요리|레시피|양념장|소스$|밥$|면$|국수|수제비|만두|김밥|샌드위치|피자|파스타|그라탕|버무림|겉절이|물김치|찜닭|백숙|샤브|덮밥|비빔/;
const RE_SHOP  = /선물세트|선물|세트$|\d+\s*(kg|KG|g|G|개|구|알|통|캔|장|줄|박스|팩|입|호|과|봉|병|수|미|마리|근|말|되|인분)|가격|시세|도매|소매|판매|구매|주문|배송|택배|특가|할인|최저가|산지직송|직거래|공구|무료배송|모종|씨앗|묘목|추천$|후기|리뷰|순위|비교|제철|답례품|주문제작/;
const RE_BRAND = /[A-Za-z]{3,}/;
const INTENT_NAMES = ["쇼핑성", "정보성", "브랜드성", "요리·조리", "품목"];
const intentOf = kw =>
  RE_HOWTO.test(kw) ? 1 : RE_DISH.test(kw) ? 3 : RE_SHOP.test(kw) ? 0 : RE_BRAND.test(kw) ? 2 : 4;

const want = (() => {
  const i = process.argv.indexOf("--section");
  if (i < 0 || !SEC) return null;
  const names = process.argv[i + 1].split(",").map(x => x.trim());
  const bits = SEC.reduce((acc, sec, si) =>
    names.includes(sec.id) || names.includes(String(sec.order)) ? acc | (1 << si) : acc, 0);
  if (!bits) { console.error("--section 에 쓸 수 있는 값: " + SEC.map(x => `${x.order}/${x.id}`).join(" ")); process.exit(1); }
  console.log("이 섹션만 담는다: " + SEC.filter((_, si) => bits & (1 << si)).map(x => x.name).join(" · "));
  return bits;
})();

/* 상품수. 21단계(아이템스카우트 내보내기)가 있으면 싣는다.
   쇼핑검색 API 가 없어져서 이게 유일한 원본이다. 없으면 0 으로 둔다.
   0 은 "없음"이지 "상품이 0개"가 아니다. 화면이 그렇게 읽는다. */
let SHOPCNT = {}, SHOPCMP = {}, SHOPCAT = {};
try {
  const j = JSON.parse(fs.readFileSync(path.join("naver-out", "shopcount.json"), "utf8"));
  SHOPCNT = j.data || {};
  SHOPCMP = j.comp || {};
  for (const [k, m] of Object.entries(j.meta || {})) if (m && m.cat) SHOPCAT[k] = m.cat;
  console.log(`상품수 ${Object.keys(SHOPCNT).length.toLocaleString()}개 · 경쟁강도 ${Object.keys(SHOPCMP).length.toLocaleString()}개 · 대표카테고리 ${Object.keys(SHOPCAT).length.toLocaleString()}개를 함께 담는다 (출처 ${j.source || "수집"}).`);
} catch { console.log("상품수 파일이 없다. 경쟁강도 칸은 '미수집'으로 나간다."); }

const secCount = new Array(SEC ? SEC.length : 0).fill(0);
let secNone = 0;
const packedAll = rows.map(r => {
  const sec = secMatch(r.kw);
  return [
    r.kw, num(r.pc), num(r.mo), num(r.depth), (COMP[r.compIdx] ?? 0),
    num(r.clickPc), num(r.clickMo), num(r.ctrPc), num(r.ctrMo),
    bidOf(r, "pc", 0), bidOf(r, "pc", 1), bidOf(r, "pc", 2),
    bidOf(r, "mo", 0), bidOf(r, "mo", 1), bidOf(r, "mo", 2),
    r.masked ? 1 : 0, intentOf(r.kw), (r.hints && r.hints[0]) || "", sec,
    SHOPCNT[r.kw] || 0, SHOPCMP[r.kw] || 0, SHOPCAT[r.kw] || "",
    r.med ? num(r.med[0]) : 0, r.med ? num(r.med[1]) : 0, dayInt(r.at), r.food == null ? -1 : r.food, r.sepTot || 0
  ];
});
{ /* 제대로 담겼는지 바로 확인한다. 전부 0 이면 또 이름을 잘못 짚은 것이다. */
  const withBid = packedAll.filter(r => r[9] || r[12]).length;
  const withComp = packedAll.filter(r => r[4]).length;
  console.log(`  입찰가 있는 키워드 ${withBid.toLocaleString()} · 경쟁도 있는 키워드 ${withComp.toLocaleString()}`);
  if (!withBid) console.log("  *** 입찰가가 하나도 없다. keywords.json 에 bid 가 안 들어있거나 이름이 또 다르다. 알려줘라. ***");
}
if (SEC) {
  for (const row of packedAll) {
    const m = row[18];
    if (!m) { secNone++; continue; }
    for (let si = 0; si < SEC.length; si++) if (m & (1 << si)) secCount[si]++;
  }
  console.log("  섹션별 키워드 수");
  SEC.forEach((sec, si) => console.log(`    ${sec.order}. ${sec.name.padEnd(12)} ${secCount[si].toLocaleString().padStart(9)}개`));
  console.log(`    ${"어디에도 안 붙음".padEnd(15)} ${secNone.toLocaleString().padStart(9)}개`);
  meta.sections = SEC.map((sec, si) => ({ id: sec.id, name: sec.name, n: secCount[si] }));
  meta.sectionNone = secNone;
}
const packed = want ? packedAll.filter(r => r[18] & want) : packedAll;
if (want) console.log(`  걸러낸 뒤 ${packed.length.toLocaleString()}개를 담는다`);

{ /* 통계는 반드시 "실제로 담는 것" 기준이어야 한다.
     전에는 566,276개 전부를 놓고 셌다. 화면에 안 들어가는 52만 개가 섞여
     품목 85.8% 같은 숫자가 나왔고, 상품수 53개도 0.0% 로 보여 쓸모가 없었다. */
  const byI = new Array(INTENT_NAMES.length).fill(0);
  for (const r of packed) byI[r[16]]++;
  console.log("  담는 것 기준 의도 분포  " + INTENT_NAMES.map((n, i) =>
    `${n} ${(byI[i] / packed.length * 100).toFixed(1)}%`).join(" · "));
  if (Math.max(...byI) / packed.length > 0.90)
    console.log("  *** 한 칸에 90% 넘게 쏠렸다. 규칙이 사실상 분류를 안 하고 있다. ***");

  const nImp = Object.keys(SHOPCNT).length;
  if (nImp) {
    const onScreen = packed.filter(r => r[19]).length;
    const inAll = packedAll.filter(r => r[19]).length;
    console.log(`  상품수 — 가져온 ${nImp.toLocaleString()}개 중 화면에 붙은 것 ${onScreen.toLocaleString()}개 (화면의 ${(onScreen / packed.length * 100).toFixed(1)}%)`);
    if (inAll > onScreen)
      console.log(`    ${(inAll - onScreen).toLocaleString()}개는 수집분에 있으나 다섯 섹션 밖이라 이번엔 안 담았다.`);
    if (nImp > inAll)
      console.log(`    ${(nImp - inAll).toLocaleString()}개는 우리가 아직 안 모은 키워드다 (띄어쓰기 변형이 대부분이다).`);
  }
}

/* 18단계(상품수)가 쓸 목표 목록을 같이 떨궈둔다.
   화면이 실제로 쓰는 키워드만, 검색량 큰 순서로. 위에서부터 채우다 멈춰도
   중요한 것부터 채워진 상태가 된다. */
{
  const list = packed.map(r => [r[0], (r[1] || 0) + (r[2] || 0)])
                     .sort((a, b) => b[1] - a[1]).map(r => r[0]);
  try {
    fs.mkdirSync("naver-out", { recursive: true });
    fs.writeFileSync(path.join("naver-out", "section-keywords.txt"), list.join("\n"), "utf8");
    console.log(`  naver-out/section-keywords.txt 에 ${list.length.toLocaleString()}개를 적어뒀다 (18단계용)`);
  } catch (e) { console.log("  목표 목록은 못 적었다: " + e.message); }
}
/* 12 MB 씩 나눠 담는다. 한 파일이 16 MB 를 넘으면 아티팩트가 안 받는다.
   처음엔 추세만 나누고 키워드는 한 파일로 뒀는데, 419,049개가 나오니
   kw.js 가 27 MB 가 됐다. 키워드도 똑같이 나눈다. */
const CAP = 10 * 1048576;   // 실측 103 bytes/키워드. 16 MB 한도에 여유를 둔다
const head = { fetchedAt: kj.fetchedAt || "", calls: kj.calls || 0, failed: (kj.failed || []).length,
  cols: "kw,pc,mo,depth,comp,clickPc,clickMo,ctrPc,ctrMo,bp1,bp2,bp3,bm1,bm2,bm3,masked,intent,hint,sec,prod,icomp,icat,medPc,medMo,day,food,sepTot",
  freshAt,
  intentNames: INTENT_NAMES,
  sections: SEC ? SEC.map(x => ({ id: x.id, name: x.name, naver: x.naver })) : [] };
fs.writeFileSync(path.join(DST, "kw-head.js"), "window.KWHEAD=" + JSON.stringify(head) + ";", "utf8");
total += Buffer.byteLength("window.KWHEAD=" + JSON.stringify(head) + ";");

const kwFiles = [];
let buf = [], bytes = 0, kn = 0;
const flushKw = () => {
  if (!buf.length) return;
  const nm = `kw-${String(kn).padStart(3,"0")}.js`;
  /* push(...arr) 은 인자가 13만 개면 스택이 터진다. concat 으로 붙인다. */
  const js = `window.KWROWS=(window.KWROWS||[]).concat(${JSON.stringify(buf)});`;
  fs.writeFileSync(path.join(DST, nm), js, "utf8");
  kwFiles.push(nm); total += Buffer.byteLength(js);
  console.log(`  → pack/${nm}  ${MB(Buffer.byteLength(js))}  (${buf.length.toLocaleString()}개)`);
  buf = []; bytes = 0; kn++;
};
for (const row of packed) {
  buf.push(row); bytes += 90;
  if (bytes > CAP) flushKw();
}
flushKw();
meta.kwFiles = kwFiles;

/* 검색량이 어떻게 퍼져 있는지 알아야 어디를 자를지 정할 수 있다 */
const vols = packed.map(r => r[1] + r[2]).sort((a,b) => a-b);
const cut = v => vols.length - vols.findIndex(x => x >= v);
meta.volume = { total: vols.length, ge10: cut(10), ge100: cut(100), ge500: cut(500), ge1000: cut(1000), ge5000: cut(5000) };
console.log(`  검색량 분포  월 10↑ ${cut(10).toLocaleString()} · 100↑ ${cut(100).toLocaleString()} · 500↑ ${cut(500).toLocaleString()} · 1,000↑ ${cut(1000).toLocaleString()} · 5,000↑ ${cut(5000).toLocaleString()}`);

/* ── 2. 구매층 ── */
const sj = read("shop.json");
if (sj) {
  const AG = ["10","20","30","40","50","60"], out = {};
  const keepS = new Set(packed.map(r => r[0]));
  for (const [k, v] of Object.entries(sj.data || {})) {
    if (!keepS.has(k)) continue;
    const d = v.device, g = v.gender, a = v.age;
    if (!d || !g || !a) continue;
    const td = Object.values(d).reduce((x,y)=>x+y,0);
    const tg = Object.values(g).reduce((x,y)=>x+y,0);
    const ta = Object.values(a).reduce((x,y)=>x+y,0);
    if (!td || !tg || !ta) continue;
    out[k] = [Math.round((d.mo||0)/td*1000), Math.round((g.f||0)/tg*1000)]
      .concat(AG.map(x => Math.round((a[x]||0)/ta*1000)));
  }
  const js = "window.SHOPDATA=" + JSON.stringify({ category: sj.category, from: sj.startDate, to: sj.endDate, d: out }) + ";";
  fs.writeFileSync(path.join(DST, "shop.js"), js, "utf8");
  meta.shop = Object.keys(out).length; total += Buffer.byteLength(js);
  console.log(`구매층 ${Object.keys(out).length.toLocaleString()}개  (원본 ${MB(size("shop.json"))})  → pack/shop.js  ${MB(Buffer.byteLength(js))}`);
} else console.log("구매층 shop.json 없음 — 건너뛴다");

/* ── 큰 파일 흘려 읽기 ──
   trend.json 이 512.3 MB 였다. Node 가 만들 수 있는 문자열이 512 MB 라
   readFileSync 가 통째로는 못 읽는다. 앞서 이걸 '파일 없음' 으로 찍었던 게 내 잘못이다.
   그래서 data 안의 항목을 하나씩 떼어 읽는다. 메모리에 다 올리지 않는다. */
async function streamTrend(file, onEntry) {
  const rs = fs.createReadStream(file, { encoding: "utf8", highWaterMark: 1 << 20 });
  let buf = "", started = false, head = null, n = 0;
  const findHead = () => {
    const i = buf.indexOf('"data"');
    if (i < 0) return false;
    const j = buf.indexOf("{", i);
    if (j < 0) return false;
    head = buf.slice(0, i);                       // startDate 등이 들어있는 앞부분
    buf = buf.slice(j + 1); started = true; return true;
  };
  /* 따옴표 안의 [ ] 는 세지 않는다 */
  const balanced = from => {
    let d = 0, str = false, esc = false;
    for (let i = from; i < buf.length; i++) {
      const c = buf[i];
      if (esc) { esc = false; continue; }
      if (c === "\\") { esc = true; continue; }
      if (c === '"') { str = !str; continue; }
      if (str) continue;
      if (c === "[") d++;
      else if (c === "]") { d--; if (!d) return i; }
    }
    return -1;
  };
  const drain = () => {
    for (;;) {
      let i = 0;
      while (i < buf.length && /[\s,]/.test(buf[i])) i++;
      if (i >= buf.length) { buf = buf.slice(i); return; }
      if (buf[i] === "}") { buf = ""; return; }     // data 끝
      if (buf[i] !== '"') { buf = buf.slice(i); return; }
      let j = i + 1, esc = false;
      while (j < buf.length) { const c = buf[j]; if (esc) esc = false; else if (c === "\\") esc = true; else if (c === '"') break; j++; }
      if (j >= buf.length) { buf = buf.slice(i); return; }   // 키가 아직 안 끝났다
      const key = JSON.parse(buf.slice(i, j + 1));
      let k = j + 1;
      while (k < buf.length && /[\s:]/.test(buf[k])) k++;
      if (k >= buf.length || buf[k] !== "[") { buf = buf.slice(i); return; }
      const end = balanced(k);
      if (end < 0) { buf = buf.slice(i); return; }            // 배열이 아직 안 끝났다
      onEntry(key, JSON.parse(buf.slice(k, end + 1))); n++;
      buf = buf.slice(end + 1);
    }
  };
  for await (const chunk of rs) {
    buf += chunk;
    if (!started) { if (!findHead()) continue; }
    drain();
  }
  if (started) drain();
  let meta = {};
  /* head 는 "data" 앞까지라 끝에 쉼표가 남는다. 그대로 붙이면 JSON.parse 가 실패해
     startDate 가 통째로 사라진다. 실제로 trendWeeks 에 unit 만 남아 있었다. */
  try { meta = JSON.parse((head || "{").replace(/,\s*$/, "") + "}"); } catch (e) { console.log(`  추세 머리말을 못 읽었다: ${e.message}`); }
  return { n, meta };
}

/* ── 3. 3년 추세 ── */
const trendPath = path.join(OUT, "trend.json");
if (fs.existsSync(trendPath)) {
  console.log(`3년 추세 (원본 ${MB(size("trend.json"))}) — 흘려 읽는다`);
  const keep = new Set(packed.map(r => r[0]));
  /* 세 가지 모양을 다 받는다.
       옛 형식  [["2023-09-11",75.5], ...]
       객체     [{period,ratio}, ...]
       새 형식  [75.5, 100, ...]     날짜는 맨 위 periods 에 한 번만 있다 */
  const enc1 = arr => (arr || []).map(pt =>
    enc(typeof pt === "number" ? pt : Array.isArray(pt) ? pt[1] : (pt && pt.ratio))).join("");
  let shard = {}, tbytes = 0, n = 0, files = [], kept = 0;
  const flush = () => {
    if (!Object.keys(shard).length) return;
    const nm = `trend-${String(n).padStart(3,"0")}.js`;
    const js = `window.TRENDDATA=window.TRENDDATA||{};Object.assign(window.TRENDDATA,${JSON.stringify(shard)});`;
    fs.writeFileSync(path.join(DST, nm), js, "utf8");
    files.push(nm); total += Buffer.byteLength(js);
    console.log(`  → pack/${nm}  ${MB(Buffer.byteLength(js))}`);
    shard = {}; tbytes = 0; n++;
  };
  const { n: seen, meta: tmeta } = await streamTrend(trendPath, (k, arr) => {
    if (!keep.has(k)) return;
    const v = enc1(arr);
    if (!v) return;
    shard[k] = v; kept++; tbytes += k.length + v.length + 6;
    if (tbytes > CAP) flush();
  });
  flush();
  console.log(`  파일 안 ${seen.toLocaleString()}개 중 ${kept.toLocaleString()}개를 담았다`);
  meta.trend = kept; meta.trendFiles = files;
  /* periods 가 있으면 그대로 넘긴다. 없으면 시작일에서 7일씩 되살린다. */
  meta.trendWeeks = { start: tmeta.startDate, end: tmeta.endDate, unit: tmeta.timeUnit || "week",
                      periods: Array.isArray(tmeta.periods) ? tmeta.periods : null };
} else console.log("3년 추세 trend.json 없음 — 건너뛴다");

meta.totalBytes = total;
fs.writeFileSync(path.join(DST, "meta.json"), JSON.stringify(meta, null, 1), "utf8");
/* 공급가표도 함께 싣는다. 22단계가 만들어두면 그대로 따라간다. */
{
  try {
    const raw = fs.readFileSync(path.join("naver-out", "supply.json"), "utf8");
    const j = JSON.parse(raw);
    const js = "window.SUPPLYDATA=" + raw + ";";
    fs.writeFileSync(path.join(DST, "supply.js"), js, "utf8");
    total += Buffer.byteLength(js);
    console.log(`공급가 ${(j.rows || []).length.toLocaleString()}건 · 공급사 ${(j.suppliers || []).length}곳  → pack/supply.js  ${(Buffer.byteLength(js) / 1048576).toFixed(2)} MB`);
  } catch { console.log("공급가 파일이 없다. 공급가 비교 탭은 안내문만 나간다. (22단계로 만든다)"); }
}

console.log(`\n합계 ${MB(total)}  →  ${DST}`);
console.log(total > 60 * 1048576
  ? "60 MB 를 넘는다. 이 상태로는 화면 한 장에 다 못 넣는다. 어디를 자를지 정해야 한다."
  : "화면에 넣을 수 있는 크기다. pack 폴더를 통째로 압축해서 보내라.");
